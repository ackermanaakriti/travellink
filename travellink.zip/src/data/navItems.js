export const navItems = [   


    {
        menuTitle: "About Us",
        link: "",
        slug: "about-us",
        Catagories: [
            {
                menuTitle: "Our Team",
                link: "/ourteam",
                slug: ""


            },
            {
                menuTitle: "Company Profile",
                link: "/about-us",
                slug: ""


            },
        ]
    },
    {
        menuTitle: "Services",
        link: "/services",
        slug: "services",
        Catagories:''
    },    
    
    {
        menuTitle: "Contact Us",
        link: "/contactus",
        slug: "contact-us",
        Catagories:''
    },
     {
        menuTitle: "Testimonials",
        link: "/testimonials",
        slug: "testimonials",
        Catagories:''
    },

];
