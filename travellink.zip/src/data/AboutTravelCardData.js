import { landscape, mapA, travel, travelLuggage } from "../assets";

export const AboutTravelCardData = [
    {
        title:'Around the world',
        discription:'Lorem ipsum dolor sit amet consectetur. Ut pulvinar aliquam in orci aliquet elit etiam et turpis.',
        image:travel,
    },
    {
        title:'No worries anymore',
        discription:'Lorem ipsum dolor sit amet consectetur. Ut pulvinar aliquam in orci aliquet elit etiam et turpis.',
        image:travelLuggage,
    },
    {
        title:'Authentic Experience',
        discription:'Lorem ipsum dolor sit amet consectetur. Ut pulvinar aliquam in orci aliquet elit etiam et turpis.',
        image:landscape,
    },
    {
        title:'Perfect Itineraries',
        discription:'Lorem ipsum dolor sit amet consectetur. Ut pulvinar aliquam in orci aliquet elit etiam et turpis.',
        image:mapA,
    },
]