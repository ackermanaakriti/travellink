import { testimonial } from "../assets";

export const testimonialsData = [
    {
        id:'1',
        summary: '“Ornare sed felis scam id ipsum. Eleifend gravida sit fringilla olla iaculis.”',
        discription:"Neque metus dictum pharetra faucibus vel in tempor quis neque. Pellentesque est aliquam est ultrices tincidunt. Id fringilla enim nibh mattis sociis. Eget feugiat facilisi nunc sagittis aliquet ultrices maecenas. Velit egestas varius urna varius aliquet. Eu eu massa faucibus in in suspendisse in justo id. Sollicitudin eu dignissim sit ut id. Eget id facilisi scelerisque egestas aenean. Lorem et at praesent id elit non faucibus auctor mus. Interdum donec faucibus eu elementum commodo. Quis blandit mauris eget quam suspendisse mauris penatibus sagittis cursus. Sed diam massa urna pretium eu platea. Id enim lobortis in amet vitae habitant. Egestas vitae porttitor montes pellentesque amet augue a. Phasellus a vehicula sem egestas placerat nunc egestas fermentum. Tristique a mauris vulputate lobortis faucibus aliquet mauris amet porttitor.", 
        name:"Andrew Sarma",
        country:"Australia",
        image: testimonial,
        packageIndividual:'Package : Annapurna Base Camp Trek', 
    },
    {
        id:'2',
        summary: '“Ornare sed felis scam id ipsum. Eleifend gravida sit fringilla olla iaculis.”',
        discription:"Neque metus dictum pharetra faucibus vel in tempor quis neque. Pellentesque est aliquam est ultrices tincidunt. Id fringilla enim nibh mattis sociis. Eget feugiat facilisi nunc sagittis aliquet ultrices maecenas. Velit egestas varius urna varius aliquet. Eu eu massa faucibus in in suspendisse in justo id. Sollicitudin eu dignissim sit ut id. Eget id facilisi scelerisque egestas aenean. Lorem et at praesent id elit non faucibus auctor mus. Interdum donec faucibus eu elementum commodo. Quis blandit mauris eget quam suspendisse mauris penatibus sagittis cursus. Sed diam massa urna pretium eu platea. Id enim lobortis in amet vitae habitant. Egestas vitae porttitor montes pellentesque amet augue a. Phasellus a vehicula sem egestas placerat nunc egestas fermentum. Tristique a mauris vulputate lobortis faucibus aliquet mauris amet porttitor.", 
        name:"Andrew Sarma",
        country:"Australia",
        image: testimonial,
        packageIndividual:'Package : Annapurna Base Camp Trek', 
    },
    {
        id:'3',
        summary: '“Ornare sed felis scam id ipsum. Eleifend gravida sit fringilla olla iaculis.”',
        discription:"Neque metus dictum pharetra faucibus vel in tempor quis neque. Pellentesque est aliquam est ultrices tincidunt. Id fringilla enim nibh mattis sociis. Eget feugiat facilisi nunc sagittis aliquet ultrices maecenas. Velit egestas varius urna varius aliquet. Eu eu massa faucibus in in suspendisse in justo id. Sollicitudin eu dignissim sit ut id. Eget id facilisi scelerisque egestas aenean. Lorem et at praesent id elit non faucibus auctor mus. Interdum donec faucibus eu elementum commodo. Quis blandit mauris eget quam suspendisse mauris penatibus sagittis cursus. Sed diam massa urna pretium eu platea. Id enim lobortis in amet vitae habitant. Egestas vitae porttitor montes pellentesque amet augue a. Phasellus a vehicula sem egestas placerat nunc egestas fermentum. Tristique a mauris vulputate lobortis faucibus aliquet mauris amet porttitor.", 
        name:"Andrew Sarma",
        country:"Australia",
        image: testimonial, 
        packageIndividual:'Package : Annapurna Base Camp Trek',
    },
    {
        id:'4',
        summary: '“Ornare sed felis scam id ipsum. Eleifend gravida sit fringilla olla iaculis.”',
        discription:"Neque metus dictum pharetra faucibus vel in tempor quis neque. Pellentesque est aliquam est ultrices tincidunt. Id fringilla enim nibh mattis sociis. Eget feugiat facilisi nunc sagittis aliquet ultrices maecenas. Velit egestas varius urna varius aliquet. Eu eu massa faucibus in in suspendisse in justo id. Sollicitudin eu dignissim sit ut id. Eget id facilisi scelerisque egestas aenean. Lorem et at praesent id elit non faucibus auctor mus. Interdum donec faucibus eu elementum commodo. Quis blandit mauris eget quam suspendisse mauris penatibus sagittis cursus. Sed diam massa urna pretium eu platea. Id enim lobortis in amet vitae habitant. Egestas vitae porttitor montes pellentesque amet augue a. Phasellus a vehicula sem egestas placerat nunc egestas fermentum. Tristique a mauris vulputate lobortis faucibus aliquet mauris amet porttitor.", 
        name:"Andrew Sarma",
        country:"Australia",
        image: testimonial, 
        packageIndividual:'Package : Annapurna Base Camp Trek',
    },
    {
        id:'5',
        summary: '“Ornare sed felis scam id ipsum. Eleifend gravida sit fringilla olla iaculis.”',
        discription:"Neque metus dictum pharetra faucibus vel in tempor quis neque. Pellentesque est aliquam est ultrices tincidunt. Id fringilla enim nibh mattis sociis. Eget feugiat facilisi nunc sagittis aliquet ultrices maecenas. Velit egestas varius urna varius aliquet. Eu eu massa faucibus in in suspendisse in justo id. Sollicitudin eu dignissim sit ut id. Eget id facilisi scelerisque egestas aenean. Lorem et at praesent id elit non faucibus auctor mus. Interdum donec faucibus eu elementum commodo. Quis blandit mauris eget quam suspendisse mauris penatibus sagittis cursus. Sed diam massa urna pretium eu platea. Id enim lobortis in amet vitae habitant. Egestas vitae porttitor montes pellentesque amet augue a. Phasellus a vehicula sem egestas placerat nunc egestas fermentum. Tristique a mauris vulputate lobortis faucibus aliquet mauris amet porttitor.", 
        name:"Andrew Sarma",
        country:"Australia",
        image: testimonial, 
        packageIndividual:'Package : Annapurna Base Camp Trek',
    },
     
]