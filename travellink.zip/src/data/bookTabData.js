export const bookTabData = [
    {
        title: 'Arrive Pokhara, explore the lake side city in the afternoon, hotel',
        description: 'Purus felis penatibus sagittis sagittis amet. Phasellus sit nec eu leo. Quam arcu tempus scelerisque tellus pretium lacus vestibulum. Malesuada volutpat sed diam nunc duis. Id lorem amet risus libero in vulputate. Dictum sed urna ut donec nec. Sagittis fermentum semper ultricies sapien aliquet pellentesque.',
        day: 'Day 1',
    },
    {
        title: 'Arrive Pokhara, explore the lake side city in the afternoon, hotel',
        description: 'Purus felis penatibus sagittis sagittis amet. Phasellus sit nec eu leo. Quam arcu tempus scelerisque tellus pretium lacus vestibulum. Malesuada volutpat sed diam nunc duis. Id lorem amet risus libero in vulputate. Dictum sed urna ut donec nec. Sagittis fermentum semper ultricies sapien aliquet pellentesque.',
        day: 'Day 2',
    },
    {
        title: 'Arrive Pokhara, explore the lake side city in the afternoon, hotel',
        description: 'Purus felis penatibus sagittis sagittis amet. Phasellus sit nec eu leo. Quam arcu tempus scelerisque tellus pretium lacus vestibulum. Malesuada volutpat sed diam nunc duis. Id lorem amet risus libero in vulputate. Dictum sed urna ut donec nec. Sagittis fermentum semper ultricies sapien aliquet pellentesque.',
        day: 'Day 3',
    },
    {
        title: 'Arrive Pokhara, explore the lake side city in the afternoon, hotel',
        description: 'Purus felis penatibus sagittis sagittis amet. Phasellus sit nec eu leo. Quam arcu tempus scelerisque tellus pretium lacus vestibulum. Malesuada volutpat sed diam nunc duis. Id lorem amet risus libero in vulputate. Dictum sed urna ut donec nec. Sagittis fermentum semper ultricies sapien aliquet pellentesque.',
        day: 'Day 4',
    },
    {
        title: 'Arrive Pokhara, explore the lake side city in the afternoon, hotel',
        description: 'Purus felis penatibus sagittis sagittis amet. Phasellus sit nec eu leo. Quam arcu tempus scelerisque tellus pretium lacus vestibulum. Malesuada volutpat sed diam nunc duis. Id lorem amet risus libero in vulputate. Dictum sed urna ut donec nec. Sagittis fermentum semper ultricies sapien aliquet pellentesque.',
        day: 'Day 5',
    },

   
]